/**
 * A value that is scaled linearly.
 * (base, level) => base * level
 */

class LinearScalable implements CapacitorScalable {
    private base: number;
    private modifier: string
    constructor(modifier: string, base: number) {
        this.base = base
        this.modifier = modifier
    }

    public scale(base: number, level: number) {
        return base * level;
    }

    public scaleF(data: CapacitorData) {
        return this.scale(this.base, data.getModifier(this.modifier))
    }

    public scaleI(data: CapacitorData) { // 
        return Math.round(this.scale(this.base, data.getModifier(this.modifier)))
    }
}