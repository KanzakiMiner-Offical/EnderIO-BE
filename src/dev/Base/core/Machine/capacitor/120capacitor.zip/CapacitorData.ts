// class CapacitorData {
//     private base: number
//     private modifiers: string[]
//     constructor(base: number, modifiers: string[]) {
//         this.base = base
//         this.modifiers = modifiers
//     }
//     public static NONE: CapacitorData = this.simple(0);

//     public static simple(base: number): CapacitorData {
//         return new CapacitorData(base, null);
//     }

//     public getModifier(modifier: string): number {
//         if (this.modifiers.indexOf(modifier)) {
//             return 0
//             // return this.modifiers.get(modifier);
//         }

//         return this.base;
//     }
// }