interface CapacitorScalable {
    scaleF(data): number
    scaleI(data): number
}