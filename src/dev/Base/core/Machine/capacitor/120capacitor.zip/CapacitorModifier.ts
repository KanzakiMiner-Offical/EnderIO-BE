// enum ECapacitorModifier {
//     ENERGY_CAPACITY = 1,
//     ENERGY_USE = 2,
//     FUEL_EFFICIENCY = 3,
//     BURNING_ENERGY_GENERATION = 4,
//     /**
//      * This should always go last as the loot picker will exclude the final item in this enum
//      * @apiNote Capacitors should never multiply the FIXED modifiers...
//      */
//     FIXED = 0
// }

// class CapacitorModifier {
//     private id: number;
//     constructor(id: number) {
//         this.id = id;
//     }

//     public static SELECTABLE_MODIFIERS = [
//         "ENERGY_CAPACITY",
//         "ENERGY_USE",
//         "FUEL_EFFICIENCY",
//         "BURNING_ENERGY_GENERATION"
//     ]

//     public static getRandomModifier(randomSource) {
//         return CapacitorModifier.SELECTABLE_MODIFIERS[Math.floor(randomSource * CapacitorModifier.SELECTABLE_MODIFIERS.length)]
//     }
// }