class FixedScalable implements CapacitorScalable {
    private value: number
    constructor(value: number) {
        this.value = value
    }

    public static ZERO: FixedScalable = new FixedScalable(0);

    public scaleF(data) {
        return Math.floor(data);
    }

    public scaleI(data) { // CapacitorData
        return this.value;
    }
}